package com.priceoptimizer.service;

import java.util.ArrayList;
import java.util.List;

public class priceoptimizer {
	
	
	public List<priceoptimizer> pricelist_less_mrp = new ArrayList<priceoptimizer>();
	public List<priceoptimizer> pricelist_equal_mrp = new ArrayList<priceoptimizer>();
	public List<priceoptimizer> pricelist_selected = new ArrayList<priceoptimizer>();
	
	
	
	

}
